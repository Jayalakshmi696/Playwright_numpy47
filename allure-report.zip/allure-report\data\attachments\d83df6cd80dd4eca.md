# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: features\Contacts.feature.spec.js >> Contacts module functionality of suite8demo application >> Verify the functionality of importing Contacts >> Example #3
- Location: .features-gen\features\Contacts.feature.spec.js:85:9

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('iframe').contentFrame().getByRole('heading', { name: 'Step 1: Upload Import File' })
Expected: visible
Error: strict mode violation: locator('iframe') resolved to 2 elements:
    1) <iframe></iframe> aka locator('iframe').first()
    2) <iframe></iframe> aka locator('iframe').nth(1)

Call log:
  - Expect "toBeVisible" locator('iframe').contentFrame().getByRole('heading', { name: 'Step 1: Upload Import File' }) with timeout 10000ms
  - waiting for locator('iframe').contentFrame().getByRole('heading', { name: 'Step 1: Upload Import File' })

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - navigation [ref=e5]:
      - generic [ref=e6]:
        - list [ref=e9]:
          - listitem [ref=e10]:
            - link [ref=e11] [cursor=pointer]:
              - /url: "#/home"
        - list [ref=e18]:
          - listitem [ref=e19]:
            - generic [ref=e20]: Contacts
          - listitem [ref=e27]:
            - generic [ref=e28]: Accounts
          - listitem [ref=e35]:
            - generic [ref=e36]: Opportunities
          - listitem [ref=e43]:
            - generic [ref=e44]: Leads
          - listitem [ref=e51]:
            - generic [ref=e52]: Quotes
          - listitem [ref=e59]:
            - generic [ref=e60]: Calendar
          - listitem [ref=e67]:
            - generic [ref=e68]: Documents
        - list [ref=e77]:
          - listitem [ref=e78]:
            - generic [ref=e79]: More
      - generic [ref=e81]:
        - list [ref=e83]:
          - listitem [ref=e84]:
            - generic "Quick Create" [ref=e85] [cursor=pointer]
        - list [ref=e92]:
          - listitem [ref=e93]:
            - generic "Recently Viewed" [ref=e94] [cursor=pointer]
        - generic [ref=e104]:
          - textbox "Search" [ref=e105]:
            - /placeholder: Search...
          - button "Search" [ref=e107] [cursor=pointer]
      - list [ref=e117]:
        - listitem [ref=e118]
    - iframe [ref=e130]
  - generic [ref=e132]:
    - generic [ref=e133]: © Supercharged by SuiteCRM © Powered By SugarCRM
    - generic [ref=e134]: Back To Top
```

# Test source

```ts
  42  |     this.headerBulkActionsDropDown = page.locator('scrm-table-header').getByRole('button', { name: 'Bulk Action' });
  43  |     this.nextPageButtonHeader = page.locator('scrm-table-header').getByRole('button', { name: 'Next page' });
  44  |     this.previousPageButtonHeader = page.locator('scrm-table-header').getByRole('button', { name: 'Previous page' });
  45  |     this.beginningPageButtonHeader = page.locator('scrm-table-header').getByRole('button', { name: 'Navigate to first page' });
  46  |     this.endPageButtonHeader = page.locator('scrm-table-header').getByRole('button', { name: 'Navigate to last page' });
  47  |    // this.pageNumberHeader = page.locator('scrm-table-header').getByText('(1 - 20 of 202)');
  48  | 
  49  |     this.footerSelectDropDown = page.locator('scrm-table-footer').getByLabel('Select Action Menu');
  50  |     this.footerBulkActionsDropDown = page.locator('scrm-table-footer').getByRole('button', { name: 'Bulk Action' });
  51  |     this.nextPageButtonFooter = page.locator('scrm-table-footer').getByRole('button', { name: 'Next page' });
  52  |     this.previousPageButtonFooter = page.locator('scrm-table-footer').getByRole('button', { name: 'Previous page' });
  53  |     this.beginningPageButtonFooter = page.locator('scrm-table-footer').getByRole('button', { name: 'Navigate to first page' });
  54  |     this.endPageButtonFooter = page.locator('scrm-table-footer').getByRole('button', { name: 'Navigate to last page' });
  55  |    // this.pageNumberFooter = page.locator('scrm-table-footer').getByText('(1 - 20 of 202)');
  56  | 
  57  |     // ----- Import vCard page -----
  58  |     this.importVCardPageTitle = page.locator('iframe').contentFrame().getByRole('heading', { name: 'Import vCard' });
  59  |     this.chooseFileButtonVCard = page.locator('iframe').contentFrame().getByRole('button', { name: 'Choose File' });
  60  |     this.importVCardButton = page.locator('iframe').contentFrame().getByRole('button', { name: 'Import vCard' });
  61  |     //this.noFileChosenLabelVCard = page.locator('iframe').contentFrame().getByText('No File Chosen').first();
  62  |     this.selectVCardAlert = page.locator('iframe').contentFrame().getByText(/select a vcard file/i).first();
  63  |     this.vCardRequiredFieldError = page.locator('.error-message, .field-error, [role="alert"]').first();
  64  |     this.importVCardPageTitlelabel = page.locator('scrm-dynamic-label').getByText('Test User1');
  65  |     this.invalidvcffileMessage = page.locator('iframe').contentFrame().getByText('vCard does not have all the');
  66  |     this.nofilevcard = page.locator('iframe').contentFrame().getByText('Alert');
  67  | 
  68  |     
  69  | 
  70  |     // ----- Import Contacts page -----
  71  |     //this.uploadImportFilePageTitle = page.locator('iframe').contentFrame().locator('h2.module-title-text').filter({ hasText: 'Step 1: Upload Import File' });
  72  |    this.uploadImportFilePageTitle = page.locator('iframe').contentFrame().getByRole('heading', { name: 'Step 1: Upload Import File' });
  73  |     this.chooseFileButtonImport = page.locator('iframe').contentFrame().getByRole('button', { name: 'Select file:' });
  74  |     this.nextButtonImport = page.locator('iframe').contentFrame().getByRole('button', { name: 'Next >' });
  75  |     this.noFileChosenLabelImport = page.locator('text=No File Chosen').first();
  76  |     this.downloadTemplateLink = page.locator('iframe').contentFrame().getByRole('link', { name: 'Download Import File Template' });
  77  |     this.createNewOnlyRadio = page.locator('iframe').contentFrame().locator('#import_create');
  78  |     this.createNewAndUpdateRadio = page.locator('iframe').contentFrame().locator('#import_update');
  79  |     this.importRequiredFieldError = page.locator('.error-message, .field-error, [role="alert"]').first();
  80  |     this.invalidImportFileMessage = page.locator('iframe').contentFrame().getByText('Invalid import file name');
  81  |     this.importVCardPageTitle = page.locator('iframe').contentFrame().getByRole('heading', { name: 'Import vCard' });
  82  |     this.step2pageTitle=page.locator('iframe').contentFrame().getByRole('heading', { name: 'Step 2: Confirm Import File' });
  83  |     //this.demolabel=page.locator('scrm-dynamic-label').getByText('John Doe');
  84  |     this.requiredFieldError = page.locator('iframe').contentFrame().getByText('Missing required fields:');
  85  |   }
  86  | 
  87  |   
  88  |   // ----- Menu actions -----
  89  |   async hoverContactsMenu() {
  90  |     logger.info('Opening contacts menu');
  91  | 
  92  | 
  93  | 
  94  |     await this.contactsMenu.hover();
  95  |     console.log('Hovered over Contacts menu');
  96  | 
  97  |     
  98  |   }
  99  |   async viewContactsMenu()
  100 |  {
  101 |  await expect(this.contactsMenu).toBeVisible();
  102 |  }
  103 | 
  104 |   async clickCreateContact() {
  105 |     await  this.createContactOption.click();
  106 |   }
  107 | 
  108 |   async clickViewContacts() {
  109 |     await this.viewContactsOption.click();
  110 |   }
  111 | 
  112 |   async clickCreateFromVCard() {
  113 | 
  114 |     console.log('Before clicking Create Contact From vCard');
  115 | 
  116 |   await this.createFromVCardOption.click();
  117 | 
  118 |   console.log('After clicking Create Contact From vCard');
  119 | }
  120 |     /*
  121 |     
  122 |     console.log('Clicked Create From vCard option');
  123 | 
  124 |     await this.createFromVCardOption.click();
  125 | 
  126 |     */
  127 |   
  128 | 
  129 |   async clickImportContacts() {
  130 |     await this.importContactsOption.click();
  131 | 
  132 |   }
  133 |   async importVCardPageVisible(){
  134 |     await expect(this.importVCardPageTitle).toBeVisible();
  135 |         console.log('Import vCard page is visible');
  136 | 
  137 |   }
  138 |   async importFilePageTitleVisible() {
  139 | 
  140 |       //await this.page.waitForURL(url =>url.toString().includes('/#/import/step1') && url.toString().includes('import_module=Contacts') && url.toString().includes('return_module=Contacts'));
  141 | 
> 142 |   await expect(this.uploadImportFilePageTitle).toBeVisible({timeout: 10000});
      |                                                ^ Error: expect(locator).toBeVisible() failed
  143 | 
  144 |   console.log('Import file page title is visible');
  145 | 
  146 |   await expect(this.uploadImportFilePageTitle).toBeVisible({
  147 |     timeout: 10000
  148 |   });
  149 | 
  150 |   console.log('Import file page title is visible');
  151 | }
  152 | 
  153 |   /*
  154 | async importFilePageTitleVisible(){
  155 |   console.log('Import file page title is visible');
  156 |   await expect(this.uploadImportFilePageTitle).toBeVisible();
  157 | }*/
  158 |    
  159 | 
  160 |   async chooseFileButtonImportVisible(){
  161 |     await this.chooseFileButtonImport.click();
  162 |   }
  163 |   async nextButtonImportVisible(){
  164 |     await expect(this.nextButtonImport).click();
  165 |   }
  166 | async step2PageTitleVisible(){
  167 |   await expect(this.step2pageTitle).toBeVisible();
  168 | } 
  169 | 
  170 | async
  171 |   async requiredFieldErrorVisible(){
  172 |     await expect(this.requiredFieldError).toBeVisible();
  173 |   }
  174 | 
  175 | 
  176 |   uploadImportFilePageTitle
  177 |   // ----- Create Contact actions -----
  178 | 
  179 | async fillContactForm({ firstName, lastName } = {}) {
  180 |   if (firstName) {
  181 |     await this.firstNameField.fill(firstName);
  182 |   }
  183 | 
  184 |   if (lastName) {
  185 |     await this.lastNameField.fill(lastName);
  186 |   }
  187 | }
  188 | 
  189 | async verifyCreatedContact() {
  190 |   console.log('Verifying Contact Detail View page');
  191 |   console.log('Current URL:', this.page.url());
  192 | 
  193 |   await expect(this.page).toHaveURL(
  194 |     /#\/contacts\/edit\?return_module=Contacts&return_action=DetailView/i,
  195 |     { timeout: 30000 }
  196 |   );
  197 | 
  198 |   console.log('Contact Detail View page is displayed successfully');
  199 |     
  200 |     }
  201 |   
  202 | 
  203 | 
  204 | 
  205 | async createContact(contact) {
  206 |   await this.hoverContactsMenu();
  207 |   await this.clickCreateContact();
  208 | 
  209 |   console.log('Contact received:', contact);
  210 | 
  211 |   const contactToCreate = {
  212 |     firstName: contact.firstName,
  213 |     lastName: contact.lastName
  214 |   };
  215 | 
  216 |   console.log(
  217 |     `Creating contact: ${contactToCreate.firstName} ${contactToCreate.lastName}`
  218 |   );
  219 | 
  220 |   await this.fillContactForm(contactToCreate);
  221 | 
  222 |   this.createdContactName =
  223 |     `${contactToCreate.firstName} ${contactToCreate.lastName}`;
  224 | 
  225 |   await this.save();
  226 | 
  227 |   console.log(`Saved contact: ${this.createdContactName}`);
  228 | 
  229 |   await this.page.waitForURL(
  230 |     /#\/contacts\/edit\?return_module=Contacts&return_action=DetailView/i,
  231 |     { timeout: 30000 }
  232 |   );
  233 | 
  234 |   console.log('Contact Detail View page opened');
  235 |   console.log('Current URL:', this.page.url());
  236 | }
  237 | 
  238 | 
  239 |   async save() {
  240 |     await this.saveButton.click();
  241 |   }
  242 | 
```